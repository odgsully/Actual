"""Claude Monitor - Real-time token usage monitoring for Claude AI"""

from claude_monitor._version import __version__

__all__ = ["__version__"]
