"""Claude Monitor CLI package."""

from .main import main

__all__ = ["main"]
