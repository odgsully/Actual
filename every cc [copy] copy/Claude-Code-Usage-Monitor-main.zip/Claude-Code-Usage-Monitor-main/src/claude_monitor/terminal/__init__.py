"""Terminal package for Claude Monitor."""

# Import directly from manager and themes without facade
__all__: list[str] = []
