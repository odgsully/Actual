"""Test package for Claude Monitor."""
